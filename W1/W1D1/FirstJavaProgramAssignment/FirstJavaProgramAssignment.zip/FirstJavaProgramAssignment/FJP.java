public class FJP{
    public static void main(String[] ars){
        System.out.println("My name is Alexis Mayoral");
        System.out.println("I am 18 years old");
        System.out.println("My hometown is Garden Grove,CA");
    }
}